# tensorflow_dll             

## environment
>win10             
>vs2015            
>cuda9.0            
>cudnn7.6            
>python3.5.2              
>tensorflow-v1.12.0               
>bazel0.22.0       
>msys2-x86_64-20190524                    

## dll lib include
[tensorflow dll lib include](https://pan.baidu.com/s/1oEVioQHMHOiC3oHKivlLmA#list/path=%2F) password：0ugf                   

## reference      
[1][windows+bazel+tensorflow-v1.12.0(GPU) build dll and lib](https://blog.csdn.net/qq_35975447/article/details/91986142)       
[2][tensorflow-windows-build-script](https://github.com/guikarist/tensorflow-windows-build-script)                 
[3][windows cmake tensorflow](https://blog.csdn.net/qq_35975447/article/details/91986142)      
           
